# XBone-Net: revised RIVF 2026 manuscript

Open `main.tex` as the main document and select **pdfLaTeX**. The source archive can be imported directly into Overleaf. Keep the supplied `.tex`, `.bib`, and `.dat` files together.

Local build with a TeX distribution containing IEEEtran, TikZ and PGFPlots:

```text
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The released PDF is six A4 pages, including references, using PDF 1.6 and the standard IEEE conference font size. The bibliography column break is controlled by `\IEEEtriggeratref{10}`; adjust it after substantial text changes.

- `classification_table.tex`, `ablation_table.tex`: audited three-seed results, in percent.
- `framework.tex`: editable vector diagram of offline adaptation and online inference.
- `ig_curves.tex`, `ig_image.dat`, `ig_text.dat`: vector plots from all 669 CTCH test cases, seed 42. Curves show means; no confidence band is claimed.
- `references.bib`: bibliography.
- `evidence/audit.json`: aggregate evidence with input file hashes.
- `REVIEW_NOTES_VI.md`: changes, evidence and items requiring author verification.

The source package does not contain patient records, predictions, trained models, or a training environment. Experimental results were recomputed from existing local artifacts, without additional training. The missing BTXRD Image-only three-seed result is deliberately left unreported.

The original files supplied in Downloads were not overwritten. This revision has not been submitted to the conference.

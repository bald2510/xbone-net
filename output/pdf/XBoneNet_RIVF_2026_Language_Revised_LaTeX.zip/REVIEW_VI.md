# Nhận xét bản RIVF_XBone_Net (1).pdf

Ngày rà soát: 16/09/2026. Đã đọc và xem bố cục cả sáu trang của PDF được cung cấp, đối chiếu cấu trúc với Chương 4 và Chương 5 của báo cáo hiện hành. Đây là lượt rà nội dung và ngôn ngữ, không phải một lần chạy lại toàn bộ thí nghiệm hay đánh giá xác suất được chấp nhận.

## Kết luận

Bài đã bao quát phần cốt lõi của nghiên cứu về phân loại X-quang kết hợp bệnh sử bằng thích nghi tiết kiệm tham số. Cấu trúc và cách trình bày kết quả nhìn chung khoa học, có sự phân biệt giữa kết quả quan sát được và giới hạn diễn giải. Tuy nhiên, một số câu trong Methods khẳng định mạnh hơn bằng chứng, và bản mới thiếu mô tả online cùng chi tiết lấy mẫu theo lớp. Những điểm này quan trọng hơn việc thêm một heatmap đẹp.

Nên bổ sung hình IG định tính nếu có thể bố trí mà vẫn đọc được trong sáu trang. Hình đó giúp giải thích cách đọc attribution cho một ca, còn biểu đồ can thiệp trên 669 ca hiện tại vẫn là bằng chứng định lượng chính. Việc thêm hình không tự giải quyết các giới hạn về dữ liệu, tính mới hoặc quan hệ nhân quả giữa hai phương thức.

## Mức bao phủ nội dung

| Nội dung đã thực hiện | Trong bản PDF người dùng gửi | Nhận xét |
|---|---|---|
| Thích nghi BiomedCLIP bằng LoRA | III-A, phương trình (1) | Đã có nguyên lý và siêu tham số. |
| Alignment theo lớp và soft targets | III-B, (2)–(5), Hình 1 | Đã có loss nhưng cần nêu batch gồm 8 lớp, mỗi lớp 2 mẫu. |
| Fusion hai chiều và phân loại | III-C, (6)–(11), Hình 2 | Cần làm rõ token projection/normalization và sửa tên effective number. |
| Suy luận online | Tiêu đề III-A có nhắc | Phần thân bản PDF chưa mô tả rõ. Bản sửa đã bổ sung. |
| Dữ liệu, thiết lập và mất cân bằng | IV-A/B, Bảng II/III | Đã có split, nguồn text và phân bố test. Phân bố train sẽ giúp giải thích rõ hơn động cơ cân bằng lớp nếu còn chỗ. |
| Phân loại, 6 baselines và Image-only | IV-C, Bảng IV | Đã có cả hai bộ dữ liệu và ba seeds. |
| Đánh đổi hiệu năng–chi phí | IV-C, Bảng V | Là điểm mạnh: nêu cả giảm bộ nhớ lẫn tăng thời gian/độ trễ. |
| Ablation kiến trúc | IV-D, Bảng VI | Đã có Phase 2 only và Concatenation. Image-only đặt ở Bảng IV là hợp lý. |
| IG trên toàn bộ CTCH test | III-D, IV-E, Hình 3 | Đã dùng 669 ca và seed 42, không còn là phân tích 44 ca. |
| Ví dụ ảnh và token attribution | Chưa có trong PDF | Là phần bổ sung giúp người đọc hiểu thí nghiệm, không phải thí nghiệm chính còn thiếu. |
| Khảo sát OOD trong khóa luận | Chưa có | Có thể để ngoài bài này vì tiêu đề và đóng góp tập trung vào phân loại. Không cần đưa toàn bộ khóa luận vào sáu trang. |

## Các sửa đổi khoa học và câu chữ đã thực hiện

1. **Effective number:** phương trình (8) của bản gửi tính `(1-beta)/(1-beta^n)`, nhưng gọi đó là effective number. Đúng hơn, `E_c=(1-beta^n)/(1-beta)` và `a_c=1/E_c`. Bản sửa giữ nguyên cơ chế weighting, chỉ sửa định nghĩa và trình bày. Nguồn gốc: [Cui et al., CVPR 2019](https://arxiv.org/abs/1901.05555).
2. **Calibration:** thay câu khẳng định label smoothing cải thiện calibration bằng mô tả nó làm mềm và regularize target. Bài chưa báo cáo độ đo calibration để chứng minh cải thiện này.
3. **Linear separability:** bỏ lý do dùng linear classifier vì embedding “is expected to be linearly separated”. Chỉ cần mô tả MLP học fused representation rồi linear head tạo logits.
4. **Lợi ích kiến trúc:** thay các khẳng định sẵn rằng Phase 1 tạo biểu diễn phân biệt tốt hơn, Phase 2 tạo ranh giới rõ hơn bằng mục tiêu tối ưu và cơ chế. Kết quả ablation là nơi đánh giá lợi ích quan sát được.
5. **Tính tái lập:** bổ sung suy luận online, batch theo lớp, kích thước fusion và normalization, training-only class counts.
6. **Văn phong:** sửa “LoRA update”, “matrixes”, “a MLP”, tham chiếu “as shown in 1” và cách viết tên BiomedCLIP. Rút phần giải thích loss trùng lặp, giữ 12 phương trình và hai hình Methods.
7. **Dấu chấm phẩy:** thay bằng `whereas`, `and`, `although`, `followed by`, hoặc tách câu tùy quan hệ ý nghĩa. Trong bảng ngắn dùng dấu phẩy. Giữ dấu chấm phẩy trong ký hiệu toán `[h_I;h_T]`, tham số mask và cú pháp vẽ LaTeX.
8. **Tên mục IV-E:** dùng `Modality Contribution and Input Dependence` để phù hợp điều đang được đo, vì các can thiệp riêng từng đầu vào chưa lượng hóa tương tác ảnh–text.

Các bảng phân loại, ablation, chi phí và các đường IG giữ nguyên số liệu trong bản gửi. BTXRD Image-only tiếp tục dùng ba giá trị tổng hợp tác giả đã cung cấp: 64.23±1.54, 32.67±1.69 và 40.21±2.57 (%). Không diễn đạt hàng đó như kết quả được tính lại từ prediction files ở lượt sửa này.

## Có nên dùng hình IG đính kèm?

Có, với vai trò minh họa. IG quy đóng góp của các thành phần đầu vào cho một đầu ra của mô hình so với đầu vào tham chiếu. Nó không tự cung cấp nhãn định vị tổn thương. Xem [Sundararajan et al., ICML 2017](https://proceedings.mlr.press/v70/sundararajan17a.html).

Hình hiện tại cần các sửa đổi sau trước khi chèn vào bài tiếng Anh:

- Đổi tiêu đề và nhãn panel sang tiếng Anh. Sửa thứ tự `(a), (b), (d)` thành `(a), (b), (c)`.
- Ghi rõ nhãn thật, nhãn dự đoán và xác suất đầu ra. Giá trị 50.0% trong ví dụ là xác suất mô hình, không phải bằng chứng về độ tin cậy lâm sàng đã được hiệu chỉnh.
- Giải thích màu của ảnh riêng với màu của text. Cần xác minh pipeline tạo hình đang dùng attribution có dấu, phần dương hay độ lớn tuyệt đối trước khi đặt colorbar. Pipeline benchmark hiện dùng phần dương của tổng attribution theo kênh và chỉ chuyển sang độ lớn tuyệt đối trong trường hợp suy biến. Chưa xác nhận screenshot được xuất bằng đúng pipeline đó.
- Giữ nguyên các từ đã thực sự đưa vào mô hình. Có thể rút phần hiển thị thành trích đoạn có đánh dấu, nhưng không sửa bệnh sử thành câu trôi chảy hơn rồi trình bày như đầu vào gốc.
- Ghi checkpoint/seed, reference, số điểm nội suy và cách chọn ca. Cần đối chiếu provenance của screenshot với thí nghiệm 669 ca trước khi khẳng định nó thuộc cùng lần đánh giá.
- Không chú giải các vùng nóng là “fracture localization”. Các vùng nóng xuất hiện ở nhiều vị trí và chưa có lesion annotation để đối chiếu.
- Nếu còn chỗ, một ca đúng và một ca sai sẽ giúp bàn luận giới hạn tốt hơn chỉ chọn ca đẹp. Nếu chỉ đủ một ca, nêu rõ đây là ví dụ minh họa, không phải đại diện thống kê cho toàn bộ test.

Ưu tiên bố cục trong sáu trang: giữ Hình 3 định lượng. Có thể rút các đoạn lặp hoặc gộp hai sơ đồ Methods để dành một panel IG gọn với chữ đọc được ở kích thước in. Không nên thu nhỏ bệnh sử đến mức không đọc được hoặc bỏ bảng chi phí/ablation để thay bằng heatmap.

## Thí nghiệm bổ sung đáng ưu tiên hơn việc chỉ thêm hình

Nếu muốn nâng đóng góp từ “mô hình phụ thuộc vào cả hai đầu vào” lên “mô hình sử dụng quan hệ phù hợp giữa ảnh và bệnh sử”, nên ưu tiên:

1. **History controls:** giữ cùng checkpoint và cùng ảnh test, so sánh bệnh sử thật, bệnh sử bị bỏ và bệnh sử hoán đổi theo quy tắc định trước. Có thể phân biệt hoán đổi cùng lớp và khác lớp để khảo sát vai trò thông tin lớp so với đặc trưng từng ca. Kết quả vẫn cần xét tới thay đổi phân phối đầu vào.
2. **Text-only control:** kiểm tra mức dự đoán có thể đạt chỉ bằng bệnh sử, đặc biệt khi text có thể chứa chẩn đoán trước đó hoặc được sinh từ metadata liên quan nhãn. Cần huấn luyện, chọn checkpoint trên train/validation trước khi đánh giá test.
3. **Isolated loss/sampler ablations:** hữu ích nếu tiếp tục nhấn mạnh từng thành phần cân bằng lớp là một đóng góp thực nghiệm độc lập.

Đây là hướng tăng bằng chứng, không phải khẳng định rằng bắt buộc có cả ba mới được nộp. Ba seeds hiện có phản ánh biến thiên do huấn luyện trên split cố định, không thay cho đánh giá bệnh viện độc lập. Đổi tên hoặc thêm heatmap không khắc phục giới hạn này.

## Phạm vi bản giao

- Bản PDF đã chỉnh vẫn sáu trang A4 và giữ tên bài/tác giả, các số liệu, 6 bảng và 3 hình của bản người dùng gửi.
- Hình ca IG đính kèm **chưa được chèn** vì yêu cầu lần này hỏi nên thêm hay không, và provenance/ý nghĩa màu cần được xác minh trước khi dùng như hình thực nghiệm.
- Nguồn LaTeX mới được phục dựng từ PDF mới kết hợp nguồn trước đó vì chưa có file `.tex` tương ứng chính xác với PDF lần này. Hai hình Methods được trích trực tiếp từ PDF mới, không vẽ lại nội dung.
- Bản sửa không phải phép cập nhật trực tiếp lên project Overleaf hiện hành và không sửa các file người dùng trong Downloads. Có nhật ký thay đổi câu chữ để áp dụng riêng vào nguồn gốc nếu cần.
- Không chạy lại mô hình hoặc toàn bộ audit prediction trong lượt sửa ngôn ngữ này. Kiểm tra gồm đối chiếu các bảng/đường cong được giữ lại, kiểm tra biên dịch và xem cả sáu trang kết quả.

# XBone-Net: RIVF language revision

This editable manuscript was reconstructed from the author's `RIVF_XBone_Net (1).pdf` received on 16 September 2026 and the preceding local LaTeX source. It is not the exact source project that produced the submitted PDF.

Open `main.tex` to compile. It includes `methods.tex`, the two classification/ablation table files, and `ig_curves.tex`. Both Methods diagrams were extracted directly from the latest supplied PDF. All classification, cost, ablation, and IG values were retained. No experiment was rerun or fabricated.

Use PDFLaTeX and BibTeX with the IEEEtran conference class. A prebuilt `main.bbl` is included. Standard compilation is PDFLaTeX, BibTeX, PDFLaTeX, PDFLaTeX. The reviewed output is six A4 pages.

`REVIEW_VI.md` contains the substantive review, recommended role of a qualitative IG panel, and remaining experimental limitations. `language_changes.json` records contextual prose replacements. The mathematical semicolon in concatenation/masking notation and semicolons required by the plotting code remain intentional.

The newly attached qualitative IG screenshot is not embedded in this revision. Verify its checkpoint and attribution color semantics before incorporating it into a paper figure.

The source PDF has no acknowledgment section, which is also the case in this reconstructed revision. This document is an editorial deliverable, not a completed venue submission/compliance check.
